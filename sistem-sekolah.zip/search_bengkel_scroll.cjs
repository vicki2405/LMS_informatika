const fs = require('fs');
const content = fs.readFileSync('c:/xampp/htdocs/PKL/resources/js/Pages/Admin/Bengkel/Index.vue', 'utf8');

const lines = content.split('\n');
lines.forEach((line, idx) => {
  if (line.includes('scroll') || line.includes('slide') || line.includes('chevron') || line.includes('Chevron') || line.includes('next') || line.includes('prev') || line.includes('left') || line.includes('right')) {
    console.log(`Line ${idx + 1}: ${line.trim()}`);
  }
});
