<?php

namespace Tests\Feature;

use App\Models\CbtBankSoal;
use App\Models\CbtJadwal;
use App\Models\CbtSesi;
use App\Models\CbtSoal;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\User;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Inertia\Testing\AssertableInertia as Assert;
use Tests\TestCase;

class StudentSecurityTest extends TestCase
{
    use RefreshDatabase;

    protected User $studentUser;

    protected Siswa $student;

    protected Kelas $kelas;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(RolePermissionSeeder::class);

        $this->kelas = Kelas::create([
            'nama_kelas' => 'X PPLG 1',
            'tingkat' => 'X',
        ]);

        $otherKelas = Kelas::create([
            'nama_kelas' => 'X PPLG 2',
            'tingkat' => 'X',
        ]);

        $this->student = Siswa::create([
            'nama' => 'Siswa Aman',
            'nis' => '1001',
            'jenis_kelamin' => 'Laki-laki',
            'kelas_id' => $this->kelas->id,
            'status' => 'Aktif',
        ]);

        Siswa::create([
            'nama' => 'Siswa Lain',
            'nis' => '1002',
            'jenis_kelamin' => 'Perempuan',
            'kelas_id' => $otherKelas->id,
            'status' => 'Aktif',
        ]);

        $this->studentUser = User::factory()->create([
            'name' => 'Nama Bukan Siswa',
            'kelas_id' => $this->kelas->id,
        ]);
        $this->studentUser->assignRole('murid');
        $this->student->update(['user_id' => $this->studentUser->id]);
    }

    public function test_student_dashboard_uses_account_bound_student(): void
    {
        $this->actingAs($this->studentUser)
            ->get(route('siswa.dashboard'))
            ->assertOk()
            ->assertInertia(fn (Assert $page) => $page
                ->where('siswaObjProp.id', $this->student->id)
                ->where('siswaObjProp.nama', 'Nama Bukan Siswa')
            );
    }

    public function test_cbt_schedule_list_hides_token_and_questions(): void
    {
        [$jadwal] = $this->makeCbtExam();

        $this->actingAs($this->studentUser, 'sanctum')
            ->getJson('/api/v1/siswa/cbt/jadwal')
            ->assertOk()
            ->assertJsonMissingPath('data.0.token')
            ->assertJsonMissingPath('data.0.soals')
            ->assertJsonPath('data.0.id', $jadwal->id)
            ->assertJsonPath('data.0.jumlahSoal', 1);
    }

    public function test_cbt_start_requires_the_correct_token(): void
    {
        [$jadwal] = $this->makeCbtExam();

        $this->actingAs($this->studentUser, 'sanctum')
            ->postJson('/api/v1/siswa/cbt/start', [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
                'token' => 'SALAH',
            ])
            ->assertForbidden();

        $this->assertDatabaseMissing('cbt_sesis', [
            'jadwal_id' => $jadwal->id,
            'siswa_id' => $this->student->id,
            'token_entered' => 'SALAH',
        ]);
    }

    public function test_cbt_start_returns_questions_and_submit_requires_started_session(): void
    {
        [$jadwal] = $this->makeCbtExam();

        $this->actingAs($this->studentUser, 'sanctum')
            ->postJson('/api/v1/siswa/cbt/start', [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
                'token' => 'ABC123',
            ])
            ->assertOk()
            ->assertJsonPath('soals.0.pertanyaan', 'Berapa 2 + 2?')
            ->assertJsonPath('soals.0.kunciJawaban', null);

        $this->assertDatabaseHas('cbt_sesis', [
            'jadwal_id' => $jadwal->id,
            'siswa_id' => $this->student->id,
            'status' => 'mengerjakan',
        ]);

        CbtSesi::where('jadwal_id', $jadwal->id)
            ->where('siswa_id', $this->student->id)
            ->delete();

        $this->actingAs($this->studentUser, 'sanctum')
            ->postJson('/api/v1/siswa/cbt/submit', [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
                'answers' => [],
            ])
            ->assertForbidden();
    }

    public function test_student_cannot_change_their_identity_name(): void
    {
        $this->actingAs($this->studentUser)
            ->patch(route('profile.update'), [
                'name' => 'Nama Palsu',
                'email' => $this->studentUser->email,
            ])
            ->assertSessionHasErrors('name');
    }

    public function test_linked_materi_cbt_flow_from_reading_to_exam_start(): void
    {
        [$jadwal] = $this->makeCbtExam();

        $materi = \App\Models\Materi::create([
            'judul' => 'Materi Prasyarat CBT',
            'tipe' => 'Slider PPT',
            'kelas_id' => $this->kelas->id,
            'cbt_jadwal_id' => $jadwal->id,
            'is_published' => true,
            'semester' => 'Ganjil',
        ]);

        // 1. Before reading materi: joining waiting room should be rejected (403)
        $this->actingAs($this->studentUser)
            ->postJson(route('siswa.cbt.gabung-ruang-tunggu'), [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
            ])
            ->assertStatus(403)
            ->assertJsonPath('success', false);

        // 2. Student completes reading the materi
        $this->actingAs($this->studentUser)
            ->postJson(route('siswa.materi.track-complete', $materi->id), [
                'siswa_id' => $this->student->id,
            ])
            ->assertOk()
            ->assertJsonPath('status', 'selesai');

        $this->assertDatabaseHas('materi_reads', [
            'materi_id' => $materi->id,
            'siswa_id' => $this->student->id,
            'status' => 'selesai',
        ]);

        // 3. After completing materi: joining waiting room must now SUCCEED (200)
        $this->actingAs($this->studentUser)
            ->postJson(route('siswa.cbt.gabung-ruang-tunggu'), [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
            ])
            ->assertOk()
            ->assertJsonPath('success', true);

        // 4. Starting CBT with valid token starts exam and returns questions
        $this->actingAs($this->studentUser)
            ->postJson(route('siswa.cbt.start'), [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
                'token' => 'ABC123',
            ])
            ->assertOk()
            ->assertJsonPath('success', true)
            ->assertJsonCount(1, 'soals');
    }

    public function test_shared_class_account_does_not_leak_other_student_homework(): void
    {
        $siswa2 = Siswa::create([
            'nama' => 'Siswa Lain',
            'kelas_id' => $this->kelas->id,
            'jenis_kelamin' => 'L',
            'status' => 'Aktif',
        ]);

        $tugas = \App\Models\Tugas::create([
            'judul' => 'Tugas Matematika',
            'mata_pelajaran' => 'Matematika',
            'kelas_id' => $this->kelas->id,
            'tenggat' => now()->addDays(2),
        ]);

        // Siswa 2 mengumpulkan tugas
        \App\Models\PengumpulanTugas::create([
            'tugas_id' => $tugas->id,
            'siswa_id' => $siswa2->id,
            'status' => 'Sudah Dikirim',
            'nilai' => 95,
        ]);

        // Siswa 1 membuka dashboard (belum mengumpulkan tugas)
        $response = $this->actingAs($this->studentUser)
            ->get(route('siswa.dashboard', ['siswa_id' => $this->student->id]));

        $response->assertOk();
        $tugasList = $response->viewData('page')['props']['tugasListProp'];
        $this->assertNotEmpty($tugasList);
        $this->assertEquals('Belum Dikerjakan', $tugasList[0]['status']);
        $this->assertNull($tugasList[0]['nilai']);
    }

    public function test_cbt_graceful_finalize_when_deadline_passed(): void
    {
        [$jadwal] = $this->makeCbtExam();

        $this->actingAs($this->studentUser)
            ->post(route('siswa.cbt.start'), [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
                'token' => 'ABC123',
            ])
            ->assertOk();

        // Simulasikan waktu sesi telah melewati batas durasi ujian
        CbtSesi::where('jadwal_id', $jadwal->id)
            ->where('siswa_id', $this->student->id)
            ->update([
                'waktu_mulai' => now()->subHours(2),
            ]);

        $soal = $jadwal->bankSoal->soals->first();

        // Kirim jawaban saat timer habis (graceful finalize)
        $response = $this->actingAs($this->studentUser)
            ->post(route('siswa.cbt.submit'), [
                'jadwal_id' => $jadwal->id,
                'siswa_id' => $this->student->id,
                'answers' => [
                    $soal->id => 'D', // Jawaban benar
                ],
            ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('cbt_nilais', [
            'jadwal_id' => $jadwal->id,
            'siswa_id' => $this->student->id,
            'nilai' => 100,
            'status' => 'Tuntas',
        ]);
    }

    public function test_student_dashboard_in_place_refresh_returns_fresh_data(): void
    {
        $version = file_exists(public_path('build/manifest.json'))
            ? md5_file(public_path('build/manifest.json'))
            : null;

        // 1. Initial dashboard request
        $resInitial = $this->actingAs($this->studentUser)
            ->withHeaders(array_filter([
                'X-Inertia' => 'true',
                'X-Inertia-Version' => $version,
            ]))
            ->get(route('siswa.dashboard', ['siswa_id' => $this->student->id]));

        $resInitial->assertOk();
        $this->assertEmpty($resInitial->json('props.tugasListProp'));

        // 2. Guru adds a new task while student is on dashboard
        \App\Models\Tugas::create([
            'judul' => 'Tugas Baru Diberikan Guru',
            'mata_pelajaran' => 'Informatika',
            'kelas_id' => $this->kelas->id,
            'tenggat' => now()->addDays(3),
        ]);

        // 3. In-place sync request (triggered by refresh button)
        $resRefreshed = $this->actingAs($this->studentUser)
            ->withHeaders(array_filter([
                'X-Inertia' => 'true',
                'X-Inertia-Version' => $version,
            ]))
            ->get(route('siswa.dashboard', ['siswa_id' => $this->student->id]));

        $resRefreshed->assertOk();
        $tugasList = $resRefreshed->json('props.tugasListProp');
        $this->assertNotEmpty($tugasList);
        $this->assertEquals('Tugas Baru Diberikan Guru', $tugasList[0]['judul']);
    }

    private function makeCbtExam(): array
    {
        $bank = CbtBankSoal::create([
            'judul' => 'Bank Soal Keamanan',
            'kelas_id' => $this->kelas->id,
            'jumlah_pilihan' => 5,
        ]);

        CbtSoal::create([
            'bank_soal_id' => $bank->id,
            'nomor_urut' => 1,
            'pertanyaan' => 'Berapa 2 + 2?',
            'opsi_a' => '1',
            'opsi_b' => '2',
            'opsi_c' => '3',
            'opsi_d' => '4',
            'opsi_e' => '5',
            'kunci_jawaban' => 'D',
            'bobot' => 1,
        ]);

        $jadwal = CbtJadwal::create([
            'bank_soal_id' => $bank->id,
            'kelas_id' => $this->kelas->id,
            'judul_ujian' => 'Ujian Keamanan',
            'durasi_menit' => 60,
            'token' => 'ABC123',
            'status' => 'aktif',
            'mode_ujian' => 'formal',
        ]);

        return [$jadwal, $bank];
    }
}
