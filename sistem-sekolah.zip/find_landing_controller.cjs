const fs = require('fs');
const path = require('path');

function searchDir(dir) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      searchDir(fullPath);
    } else if (file.endsWith('.php')) {
      const content = fs.readFileSync(fullPath, 'utf8');
      if (content.includes("'Welcome'") || content.includes('"Welcome"')) {
        console.log(`Found in: ${fullPath}`);
      }
    }
  }
}

searchDir('c:/xampp/htdocs/PKL/app/Http/Controllers');
