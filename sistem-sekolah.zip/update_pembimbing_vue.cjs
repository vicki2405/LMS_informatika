const fs = require('fs');
const path = 'c:/xampp/htdocs/PKL/resources/js/Pages/Pembimbing/Dashboard.vue';
let content = fs.readFileSync(path, 'utf8');

const oldTableCol = `                                                 <td class="whitespace-nowrap px-3 py-4 text-sm text-slate-600">
                                                     <div class="font-medium">{{ siswa.kelas }}</div>
                                                     <div class="text-xs text-indigo-500 font-semibold mt-0.5">{{ siswa.jurusan }}</div>
                                                 </td>`;

const newTableCol = `                                                 <td class="whitespace-nowrap px-3 py-4 text-sm text-slate-600">
                                                     <div class="font-medium">{{ siswa.kelas }}</div>
                                                     <div v-if="siswa.wali_kelas && siswa.wali_kelas !== '-'" class="text-[11px] text-slate-400 font-semibold mt-0.5">Wali: {{ siswa.wali_kelas }}</div>
                                                     <div class="text-xs text-indigo-500 font-semibold mt-0.5">{{ siswa.jurusan }}</div>
                                                 </td>`;

const oldMobileRow = `                                             <div class="flex justify-between items-center py-2 border-b border-slate-50">
                                                 <span class="text-xs text-slate-400 font-medium uppercase tracking-wider">Kelas</span>
                                                 <span class="font-semibold text-slate-700">{{ siswa.kelas }}</span>
                                             </div>`;

const newMobileRow = `                                             <div class="flex justify-between items-center py-2 border-b border-slate-50">
                                                 <span class="text-xs text-slate-400 font-medium uppercase tracking-wider">Kelas</span>
                                                 <span class="font-semibold text-slate-700">{{ siswa.kelas }}</span>
                                             </div>
                                             <div v-if="siswa.wali_kelas && siswa.wali_kelas !== '-'" class="flex justify-between items-center py-2 border-b border-slate-50">
                                                 <span class="text-xs text-slate-400 font-medium uppercase tracking-wider">Wali Kelas</span>
                                                 <span class="font-semibold text-slate-700">{{ siswa.wali_kelas }}</span>
                                             </div>`;

if (content.includes(oldTableCol) && content.includes(oldMobileRow)) {
  content = content.replace(oldTableCol, newTableCol);
  content = content.replace(oldMobileRow, newMobileRow);
  fs.writeFileSync(path, content, 'utf8');
  console.log('VUE_UPDATE_SUCCESS');
} else {
  console.log('VUE_UPDATE_FAILED: target not found');
}
