<?php

namespace App\Providers;

use Illuminate\Support\Facades\Vite;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Vite::prefetch(concurrency: 3);

        if (app()->environment('production') || request()->header('X-Forwarded-Proto') === 'https' || request()->server('HTTPS') === 'on') {
            \Illuminate\Support\Facades\URL::forceScheme('https');
        }
    }
}
