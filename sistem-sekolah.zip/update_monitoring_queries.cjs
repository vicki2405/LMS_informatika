const fs = require('fs');

// 1. Edit MonitoringController.php
const controllerPath = 'c:/xampp/htdocs/PKL/app/Http/Controllers/Admin/MonitoringController.php';
let controllerContent = fs.readFileSync(controllerPath, 'utf8');

const oldIndexQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel'])
            ->select('monitorings.*')
            ->selectRaw('ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke')
            ->withCount(['details as pelanggaran_count' => function ($q) {
                $q->where('is_pelanggaran', true);
            }]);`;

const newIndexQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel'])
            ->select('monitorings.*')
            ->join(
                \\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke FROM monitorings) as sub'),
                'sub.id', '=', 'monitorings.id'
            )
            ->selectRaw('sub.monitoring_ke')
            ->withCount(['details as pelanggaran_count' => function ($q) {
                $q->where('is_pelanggaran', true);
            }]);`;

const oldIndexKeFilter = `        if ($request->filled('monitoring_ke')) {
            $monitoringKe = (int) $request->monitoring_ke;
            $query->whereIn('monitorings.id', function ($q) use ($monitoringKe) {
                $q->select('id')
                  ->from(\\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS rn FROM monitorings) as temp'))
                  ->where('rn', $monitoringKe);
            });
        }`;

const newIndexKeFilter = `        if ($request->filled('monitoring_ke')) {
            $query->where('sub.monitoring_ke', $request->monitoring_ke);
        }`;

const oldPdfQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel', 'details.siswa.kelas'])
            ->select('monitorings.*')
            ->selectRaw('ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke')
            ->withCount(['details as pelanggaran_count' => function ($q) {
                $q->where('is_pelanggaran', true);
            }]);`;

const newPdfQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel', 'details.siswa.kelas'])
            ->select('monitorings.*')
            ->join(
                \\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke FROM monitorings) as sub'),
                'sub.id', '=', 'monitorings.id'
            )
            ->selectRaw('sub.monitoring_ke')
            ->withCount(['details as pelanggaran_count' => function ($q) {
                $q->where('is_pelanggaran', true);
            }]);`;

const oldPdfKeFilter = `        if (! empty($filters['monitoring_ke'])) {
            $monitoringKe = (int) $filters['monitoring_ke'];
            $query->whereIn('monitorings.id', function ($q) use ($monitoringKe) {
                $q->select('id')
                  ->from(\\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS rn FROM monitorings) as temp'))
                  ->where('rn', $monitoringKe);
            });
        }`;

const newPdfKeFilter = `        if (! empty($filters['monitoring_ke'])) {
            $query->where('sub.monitoring_ke', $filters['monitoring_ke']);
        }`;

if (controllerContent.includes(oldIndexQuery) && controllerContent.includes(oldIndexKeFilter) && controllerContent.includes(oldPdfQuery) && controllerContent.includes(oldPdfKeFilter)) {
  controllerContent = controllerContent.replace(oldIndexQuery, newIndexQuery);
  controllerContent = controllerContent.replace(oldIndexKeFilter, newIndexKeFilter);
  controllerContent = controllerContent.replace(oldPdfQuery, newPdfQuery);
  controllerContent = controllerContent.replace(oldPdfKeFilter, newPdfKeFilter);
  fs.writeFileSync(controllerPath, controllerContent, 'utf8');
  console.log('CONTROLLER_QUERIES_UPDATE_SUCCESS');
} else {
  console.log('CONTROLLER_QUERIES_UPDATE_FAILED: targets not found');
}

// 2. Edit MonitoringExport.php
const exportPath = 'c:/xampp/htdocs/PKL/app/Exports/MonitoringExport.php';
let exportContent = fs.readFileSync(exportPath, 'utf8');

const oldSummaryExportQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel'])
            ->select('monitorings.*')
            ->selectRaw('ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke')
            ->withCount(['details as pelanggaran_count' => function ($q) {
                $q->where('is_pelanggaran', true);
            }]);`;

const newSummaryExportQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel'])
            ->select('monitorings.*')
            ->join(
                \\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke FROM monitorings) as sub'),
                'sub.id', '=', 'monitorings.id'
            )
            ->selectRaw('sub.monitoring_ke')
            ->withCount(['details as pelanggaran_count' => function ($q) {
                $q->where('is_pelanggaran', true);
            }]);`;

const oldSummaryKeFilter = `        if (! empty($this->filters['monitoring_ke'])) {
            $monitoringKe = (int) $this->filters['monitoring_ke'];
            $query->whereIn('monitorings.id', function ($q) use ($monitoringKe) {
                $q->select('id')
                  ->from(\\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS rn FROM monitorings) as temp'))
                  ->where('rn', $monitoringKe);
            });
        }`;

const newSummaryKeFilter = `        if (! empty($this->filters['monitoring_ke'])) {
            $query->where('sub.monitoring_ke', $this->filters['monitoring_ke']);
        }`;

const oldDetailExportQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel', 'details.siswa.kelas'])
            ->select('monitorings.*')
            ->selectRaw('ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke')
            ->whereHas('details', function ($q) {
                $q->where('is_pelanggaran', true);
            });`;

const newDetailExportQuery = `        $query = Monitoring::query()
            ->with(['pembimbing.user', 'bengkel', 'details.siswa.kelas'])
            ->select('monitorings.*')
            ->join(
                \\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY bengkel_id, pembimbing_id ORDER BY tanggal_kunjungan, id) AS monitoring_ke FROM monitorings) as sub'),
                'sub.id', '=', 'monitorings.id'
            )
            ->selectRaw('sub.monitoring_ke')
            ->whereHas('details', function ($q) {
                $q->where('is_pelanggaran', true);
            });`;

const oldDetailKeFilter = `        if (! empty($this->filters['monitoring_ke'])) {
            $monitoringKe = (int) $this->filters['monitoring_ke'];
            $query->whereIn('monitorings.id', function ($q) use ($monitoringKe) {
                $q->select('id')
                  ->from(\\Illuminate\\Support\\Facades\\DB::raw('(SELECT id, ROW_NUMBER() OVER (PARTITION BY m1.bengkel_id, m1.pembimbing_id ORDER BY m1.tanggal_kunjungan, m1.id) AS rn FROM monitorings as m1) as temp'))
                  ->where('rn', $monitoringKe);
            });
        }`;

const newDetailKeFilter = `        if (! empty($this->filters['monitoring_ke'])) {
            $query->where('sub.monitoring_ke', $this->filters['monitoring_ke']);
        }`;

if (exportContent.includes(oldSummaryExportQuery) && exportContent.includes(oldSummaryKeFilter) && exportContent.includes(oldDetailExportQuery) && exportContent.includes(oldDetailKeFilter)) {
  exportContent = exportContent.replace(oldSummaryExportQuery, newSummaryExportQuery);
  exportContent = exportContent.replace(oldSummaryKeFilter, newSummaryKeFilter);
  exportContent = exportContent.replace(oldDetailExportQuery, newDetailExportQuery);
  exportContent = exportContent.replace(oldDetailKeFilter, newDetailKeFilter);
  fs.writeFileSync(exportPath, exportContent, 'utf8');
  console.log('EXPORT_QUERIES_UPDATE_SUCCESS');
} else {
  console.log('EXPORT_QUERIES_UPDATE_FAILED: targets not found');
}
