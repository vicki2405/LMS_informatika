<script setup>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue';
import axios from 'axios';
import { renderFormulaContent } from '@/Utils/formulaRenderer';
import { showToast } from '@/Utils/sweetalert';

const props = defineProps({
  materiList: { type: Array, default: () => [] },
  siswaList: { type: Array, default: () => [] },
  siswaObj: { type: Object, default: () => ({}) },
  activeSiswa: { type: Object, default: () => null },
  targetMateriId: { type: [Number, String], default: null },
});

const emit = defineEmits(['change-view', 'switch-siswa', 'start-cbt-with-token', 'materi-completed']);

// 1. Shared Class Account Student Identity Management
const activeSiswaId = ref(null);
const showIdentityModal = ref(false);
const studentSearchQuery = ref('');

onMounted(() => {
  try {
    const savedId = localStorage.getItem('siswacloud_active_siswa_id');
    if (savedId && props.siswaList.some(s => String(s.id) === String(savedId))) {
      activeSiswaId.value = Number(savedId);
    } else if (props.siswaObj?.id && props.siswaList.some(s => String(s.id) === String(props.siswaObj.id))) {
      activeSiswaId.value = Number(props.siswaObj.id);
    } else if (props.siswaList.length > 0) {
      showIdentityModal.value = true;
    }
  } catch (e) {
    if (props.siswaList.length > 0) activeSiswaId.value = props.siswaList[0].id;
  }
});

const activeSiswa = computed(() => {
  if (props.activeSiswa) return props.activeSiswa;
  if (!activeSiswaId.value) return null;
  return props.siswaList.find(s => String(s.id) === String(activeSiswaId.value)) || null;
});

function selectStudent(student) {
  activeSiswaId.value = student.id;
  try {
    localStorage.setItem('siswacloud_active_siswa_id', String(student.id));
  } catch (e) {}
  showIdentityModal.value = false;
  showToast(`Halo ${student.nama}, selamat belajar!`, 'success');
}

function switchStudent() {
  emit('switch-siswa');
  studentSearchQuery.value = '';
  showIdentityModal.value = true;
}

const filteredSiswaList = computed(() => {
  if (!studentSearchQuery.value.trim()) return props.siswaList;
  const q = studentSearchQuery.value.toLowerCase();
  return props.siswaList.filter(s => s.nama.toLowerCase().includes(q) || (s.nis && s.nis.toLowerCase().includes(q)));
});

// 2. Filter & Search Materi
function getInitialSemester() {
  try {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('siswa_active_semester') : null;
    if (saved && ['Ganjil', 'Genap', 'Semua'].includes(saved)) {
      return saved;
    }
  } catch (e) {}
  const currentMonth = new Date().getMonth() + 1;
  return (currentMonth >= 1 && currentMonth <= 6) ? 'Genap' : 'Ganjil';
}

const selectedSemester = ref(getInitialSemester());
const selectedTipe = ref('Semua');
const selectedMapel = ref('Semua');
const selectedStatus = ref('Semua'); // 'Semua', 'belum_baca', 'sedang_membaca', 'selesai'
const searchQuery = ref('');
const viewMode = ref('cards'); // 'cards' | 'compact'

watch(selectedSemester, (newVal) => {
  try {
    if (typeof window !== 'undefined') localStorage.setItem('siswa_active_semester', newVal);
  } catch (e) {}
});

function getStudentReadStatus(materi) {
  if (!activeSiswaId.value || !materi.reads) return { status: 'belum_baca', progress: 0 };
  const record = materi.reads.find(r => String(r.siswaId) === String(activeSiswaId.value));
  if (!record) return { status: 'belum_baca', progress: 0 };
  return {
    status: record.status || 'sedang_membaca',
    progress: record.progressPersen || (record.status === 'selesai' ? 100 : 25),
  };
}

// Dynamic List of Available Mapels
const availableMapels = computed(() => {
  const mapels = new Set();
  (props.materiList || []).forEach(m => {
    if (m.mapel) mapels.add(m.mapel);
  });
  return Array.from(mapels);
});

// Summary Counts for Status Tabs
const materiCounts = computed(() => {
  const list = props.materiList || [];
  let tuntas = 0;
  let sedang = 0;
  let belum = 0;
  list.forEach(m => {
    const st = getStudentReadStatus(m).status;
    if (st === 'selesai') tuntas++;
    else if (st === 'sedang_membaca') sedang++;
    else belum++;
  });
  return {
    total: list.length,
    tuntas,
    sedang,
    belum,
  };
});

const filteredMateri = computed(() => {
  let list = props.materiList || [];
  if (selectedSemester.value !== 'Semua') {
    list = list.filter(m => (m.semester || 'Ganjil') === selectedSemester.value);
  }

  if (selectedTipe.value !== 'Semua') {
    list = list.filter(m => m.tipe === selectedTipe.value);
  }

  if (selectedMapel.value !== 'Semua') {
    list = list.filter(m => (m.mapel || '') === selectedMapel.value);
  }

  if (selectedStatus.value !== 'Semua') {
    list = list.filter(m => getStudentReadStatus(m).status === selectedStatus.value);
  }

  if (searchQuery.value.trim()) {
    const q = searchQuery.value.toLowerCase();
    list = list.filter(m => 
      (m.judul || '').toLowerCase().includes(q) || 
      (m.deskripsi || '').toLowerCase().includes(q) || 
      (m.mapel || '').toLowerCase().includes(q) ||
      (m.tpKode || '').toLowerCase().includes(q)
    );
  }

  return list;
});

function resetFilters() {
  selectedSemester.value = 'Semua';
  selectedTipe.value = 'Semua';
  selectedMapel.value = 'Semua';
  selectedStatus.value = 'Semua';
  searchQuery.value = '';
}

// 3. Presentation State
const showReader = ref(false);
const activeMateri = ref(null);
const currentSlideIndex = ref(0);
const isMarkingComplete = ref(false);
const isCompletedForActiveSiswa = ref(false);
const userSelectedTheme = ref(null);

// Lock body scrolling when reader is active to prevent viewport pushing
watch(showReader, (val) => {
  if (typeof document !== 'undefined') {
    if (val) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }
});

onUnmounted(() => {
  if (typeof document !== 'undefined') {
    document.body.style.overflow = '';
  }
});

// Mobile Swipe Gestures for Slides (Safe: strictly separates vertical reading from horizontal slide change)
let touchStartX = 0;
let touchStartY = 0;

function handleTouchStart(e) {
  if (!e.changedTouches || e.changedTouches.length === 0) return;
  touchStartX = e.changedTouches[0].clientX;
  touchStartY = e.changedTouches[0].clientY;
}

function handleTouchEnd(e) {
  if (!e.changedTouches || e.changedTouches.length === 0) return;
  const deltaX = e.changedTouches[0].clientX - touchStartX;
  const deltaY = e.changedTouches[0].clientY - touchStartY;
  // Require clear horizontal intent (> 60px and twice vertical movement) so reading vertical scroll is never interrupted
  if (Math.abs(deltaX) > 60 && Math.abs(deltaX) > Math.abs(deltaY) * 2.0) {
    if (deltaX < 0) {
      nextSlide();
    } else {
      prevSlide();
    }
  }
}
const isFullscreenMode = ref(false);

const activeTheme = computed(() => {
  return userSelectedTheme.value || activeMateri.value?.theme || 'dark';
});

// Theme Definitions for True Executive Presentation Slides
const THEME_STYLES = {
  dark: {
    bg: 'bg-slate-950 text-slate-100',
    card: 'bg-gradient-to-b from-slate-900/95 via-slate-900/90 to-slate-950/95 border-cyan-500/30 text-white shadow-[0_20px_60px_-15px_rgba(6,182,212,0.15)]',
    header: 'bg-slate-950/95 border-white/10 text-white',
    accentText: 'text-cyan-400',
    accentBg: 'bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 font-black',
    highlightBox: 'bg-cyan-950/40 border-cyan-400/40 text-cyan-200',
    badge: 'bg-cyan-500/15 border-cyan-400/40 text-cyan-300',
    glow: 'rgba(6, 182, 212, 0.12)',
  },
  light: {
    bg: 'bg-slate-100 text-slate-900',
    card: 'bg-gradient-to-b from-white via-slate-50 to-white border-slate-300 text-slate-900 shadow-[0_20px_60px_-15px_rgba(79,70,229,0.15)]',
    header: 'bg-white/95 border-slate-200 text-slate-900',
    accentText: 'text-indigo-600',
    accentBg: 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black',
    highlightBox: 'bg-indigo-50 border-indigo-200 text-indigo-900',
    badge: 'bg-indigo-50 border-indigo-300 text-indigo-700',
    glow: 'rgba(79, 70, 229, 0.08)',
  },
  navy: {
    bg: 'bg-[#030d22] text-blue-50',
    card: 'bg-gradient-to-b from-[#081836]/95 via-[#06142e] to-[#040f24] border-sky-400/30 text-white shadow-[0_20px_60px_-15px_rgba(56,189,248,0.15)]',
    header: 'bg-[#030d22]/95 border-blue-500/20 text-white',
    accentText: 'text-sky-400',
    accentBg: 'bg-gradient-to-r from-sky-400 to-blue-500 text-slate-950 font-black',
    highlightBox: 'bg-blue-950/60 border-sky-400/40 text-sky-200',
    badge: 'bg-sky-500/15 border-sky-400/40 text-sky-300',
    glow: 'rgba(56, 189, 248, 0.12)',
  },
  emerald: {
    bg: 'bg-[#021d15] text-emerald-50',
    card: 'bg-gradient-to-b from-[#052e22]/95 via-[#04241b] to-[#021912] border-emerald-400/30 text-white shadow-[0_20px_60px_-15px_rgba(16,185,129,0.15)]',
    header: 'bg-[#021d15]/95 border-emerald-500/20 text-white',
    accentText: 'text-emerald-400',
    accentBg: 'bg-gradient-to-r from-emerald-400 to-teal-500 text-slate-950 font-black',
    highlightBox: 'bg-emerald-950/60 border-emerald-400/40 text-emerald-200',
    badge: 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300',
    glow: 'rgba(16, 185, 129, 0.12)',
  },
  aurora: {
    bg: 'bg-[#10071a] text-pink-50',
    card: 'bg-gradient-to-b from-[#1a0c2b]/95 via-[#140824] to-[#0e051a] border-purple-400/30 text-white shadow-[0_20px_60px_-15px_rgba(244,63,94,0.18)]',
    header: 'bg-[#10071a]/95 border-purple-500/20 text-white',
    accentText: 'text-rose-400',
    accentBg: 'bg-gradient-to-r from-rose-500 via-pink-500 to-amber-400 text-slate-950 font-black',
    highlightBox: 'bg-purple-950/60 border-rose-400/40 text-rose-200',
    badge: 'bg-rose-500/15 border-rose-400/40 text-rose-300',
    glow: 'rgba(244, 63, 94, 0.15)',
  },
  monochrome: {
    bg: 'bg-slate-950 text-slate-100',
    card: 'bg-gradient-to-b from-slate-900/95 via-slate-900/90 to-slate-950/95 border-white/20 text-white shadow-[0_20px_60px_-15px_rgba(255,255,255,0.08)] backdrop-blur-xl',
    header: 'bg-slate-950/95 border-white/10 text-white',
    accentText: 'text-slate-200',
    accentBg: 'bg-gradient-to-r from-slate-100 to-slate-300 text-slate-950 font-black',
    highlightBox: 'bg-white/5 border-white/20 text-slate-200',
    badge: 'bg-white/10 border-white/20 text-slate-200',
    glow: 'rgba(255, 255, 255, 0.08)',
  },
};

const currentThemeClass = computed(() => {
  return THEME_STYLES[activeTheme.value] || THEME_STYLES.dark;
});

const currentSlides = computed(() => {
  return activeMateri.value?.kegiatan || [];
});

const currentSlide = computed(() => {
  return currentSlides.value[currentSlideIndex.value] || null;
});

const slideProgressPercent = computed(() => {
  if (!currentSlides.value.length) return 100;
  return Math.round(((currentSlideIndex.value + 1) / currentSlides.value.length) * 100);
});

// YouTube embed parser
const youtubeEmbedUrl = computed(() => {
  if (!activeMateri.value || activeMateri.value.tipe !== 'Video YouTube' || !activeMateri.value.fileUrl) return null;
  try {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = activeMateri.value.fileUrl.match(regExp);
    if (match && match[2].length === 11) {
      return `https://www.youtube.com/embed/${match[2]}?autoplay=1&rel=0`;
    }
  } catch (e) {
    return null;
  }
  return null;
});

// Open Reader
async function openMateri(materi) {
  if (!activeSiswa.value) {
    showIdentityModal.value = true;
    return;
  }

  activeMateri.value = materi;
  userSelectedTheme.value = materi.theme || 'dark';
  currentSlideIndex.value = 0;
  showReader.value = true;

  const readStatus = getStudentReadStatus(materi);
  isCompletedForActiveSiswa.value = readStatus.status === 'selesai';

  // Record track open in backend
  try {
    await axios.post(route('siswa.materi.track-open', materi.id), {
      siswa_id: activeSiswa.value.id,
      progress_persen: currentSlides.value.length > 0 ? Math.round((1 / currentSlides.value.length) * 100) : 50,
    });
    if (!materi.reads) materi.reads = [];
    const rec = materi.reads.find(r => String(r.siswaId) === String(activeSiswa.value.id));
    if (!rec) {
      materi.reads.push({ siswaId: activeSiswa.value.id, status: 'sedang_membaca', progressPersen: 25 });
    }
  } catch (err) {
    console.error('Track open failed:', err);
  }
}

// Toggle browser fullscreen
async function toggleBrowserFullscreen() {
  try {
    if (!document.fullscreenElement) {
      const docEl = document.documentElement;
      if (docEl.requestFullscreen) await docEl.requestFullscreen();
      isFullscreenMode.value = true;
    } else {
      if (document.exitFullscreen) await document.exitFullscreen();
      isFullscreenMode.value = false;
    }
  } catch (e) {}
}

// Slide Directional Transition & Auto-Play State
const slideTransition = ref('slide-left');
const isAutoPlaying = ref(false);
let autoPlayTimer = null;
const autoPlaySeconds = 5;

function toggleAutoPlay() {
  isAutoPlaying.value = !isAutoPlaying.value;
  if (isAutoPlaying.value) {
    startAutoPlay();
    showToast('Putar slide otomatis aktif (5 dtk)', 'info');
  } else {
    stopAutoPlay();
    showToast('Putar slide otomatis dijeda', 'info');
  }
}

function startAutoPlay() {
  stopAutoPlay();
  autoPlayTimer = setInterval(() => {
    nextSlide();
  }, autoPlaySeconds * 1000);
}

function stopAutoPlay() {
  if (autoPlayTimer) {
    clearInterval(autoPlayTimer);
    autoPlayTimer = null;
  }
}

onUnmounted(() => {
  stopAutoPlay();
});

// Close Reader & Exit Fullscreen
function closeReader() {
  stopAutoPlay();
  isAutoPlaying.value = false;
  try {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    }
  } catch (e) {}
  showReader.value = false;
  activeMateri.value = null;
  isFullscreenMode.value = false;
}

// Next / Prev Slide with smooth directional transitions
function nextSlide() {
  if (currentSlideIndex.value < currentSlides.value.length - 1) {
    slideTransition.value = 'slide-left';
    currentSlideIndex.value++;
    updateReadingProgress();
  } else if (isAutoPlaying.value) {
    // Loop back to start in autoplay mode
    slideTransition.value = 'slide-left';
    currentSlideIndex.value = 0;
    updateReadingProgress();
  }
}

function prevSlide() {
  if (currentSlideIndex.value > 0) {
    slideTransition.value = 'slide-right';
    currentSlideIndex.value--;
  }
}

function goToSlide(idx) {
  if (idx >= 0 && idx < currentSlides.value.length) {
    slideTransition.value = idx > currentSlideIndex.value ? 'slide-left' : 'slide-right';
    currentSlideIndex.value = idx;
    updateReadingProgress();
  }
}

async function updateReadingProgress() {
  if (!activeMateri.value || !activeSiswa.value || isCompletedForActiveSiswa.value) return;
  const progress = slideProgressPercent.value;
  try {
    await axios.post(route('siswa.materi.track-open', activeMateri.value.id), {
      siswa_id: activeSiswa.value.id,
      progress_persen: progress,
    });
  } catch (e) {}
}

async function markCompleted() {
  if (!activeMateri.value || !activeSiswa.value || isMarkingComplete.value) return;
  isMarkingComplete.value = true;

  try {
    await axios.post(route('siswa.materi.track-complete', activeMateri.value.id), {
      siswa_id: activeSiswa.value.id,
    });

    isCompletedForActiveSiswa.value = true;
    showToast('Selamat! Anda telah menyelesaikan materi ini 🎉', 'success');

    if (!activeMateri.value.reads) activeMateri.value.reads = [];
    const rec = activeMateri.value.reads.find(r => String(r.siswaId) === String(activeSiswa.value.id));
    if (rec) {
      rec.status = 'selesai';
      rec.progressPersen = 100;
    } else {
      activeMateri.value.reads.push({
        siswaId: activeSiswa.value.id,
        status: 'selesai',
        progressPersen: 100,
      });
    }

    emit('materi-completed', {
      materiId: activeMateri.value.id,
      siswaId: activeSiswa.value.id,
    });
  } catch (err) {
    showToast('Gagal mencatat penyelesaian materi.', 'error');
  } finally {
    isMarkingComplete.value = false;
  }
}

const isCopiedToken = ref(false);

function copyToken(token) {
  if (!token) return;
  if (navigator?.clipboard?.writeText) {
    navigator.clipboard.writeText(token);
    isCopiedToken.value = true;
    showToast('Token CBT berhasil disalin: ' + token, 'success');
    setTimeout(() => { isCopiedToken.value = false; }, 2500);
  }
}

function jumpToCbtWithToken(cbtJadwal) {
  closeReader();
  emit('start-cbt-with-token', {
    jadwalId: cbtJadwal.id,
    token: cbtJadwal.token,
  });
}

function jumpToCbt() {
  if (activeMateri.value?.cbtJadwal) {
    jumpToCbtWithToken(activeMateri.value.cbtJadwal);
  } else {
    closeReader();
    emit('change-view', 'cbt');
  }
}

watch(() => props.targetMateriId, (newId) => {
  if (newId) {
    const target = (props.materiList || []).find(m => String(m.id) === String(newId));
    if (target) {
      openMateri(target);
    }
  }
}, { immediate: true });

// Keyboard navigation (ArrowLeft, ArrowRight, Space, Escape)
function handleKeyDown(e) {
  if (!showReader.value) return;
  if (e.key === 'ArrowRight' || e.key === ' ') {
    e.preventDefault();
    nextSlide();
  } else if (e.key === 'ArrowLeft') {
    e.preventDefault();
    prevSlide();
  } else if (e.key === 'Escape') {
    closeReader();
  } else if (e.key === 'f' || e.key === 'F') {
    toggleBrowserFullscreen();
  }
}

onMounted(() => {
  window.addEventListener('keydown', handleKeyDown);
});

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeyDown);
});
</script>

<template>
  <div class="space-y-4 sm:space-y-6 pb-36 animate-in fade-in duration-300">

    <!-- Active Student Identity Card (For Shared Class Account) -->
    <div class="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-white/10 rounded-2xl sm:rounded-3xl p-3.5 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 shadow-xl">
      <div class="flex items-center gap-3 min-w-0">
        <div class="w-10 h-10 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center font-black text-lg sm:text-xl shrink-0 shadow-md">
          🎓
        </div>
        <div class="min-w-0">
          <div class="text-[9px] sm:text-[10px] text-cyan-400 font-mono font-bold uppercase tracking-wider">
            Siswa Pembaca Aktif:
          </div>
          <div v-if="activeSiswa" class="text-sm sm:text-lg font-black text-white truncate flex items-center gap-2">
            <span>{{ activeSiswa.nama }}</span>
            <span class="text-[11px] sm:text-xs text-gray-400 font-mono font-normal">NIS: {{ activeSiswa.nis || '-' }}</span>
          </div>
          <div v-else class="text-xs sm:text-sm font-bold text-amber-300">
            ⚠️ Belum memilih nama siswa
          </div>
        </div>
      </div>

      <button
        @click="switchStudent"
        type="button"
        class="w-full sm:w-auto min-h-[42px] px-4 py-2 rounded-xl sm:rounded-2xl bg-white/10 hover:bg-white/20 border border-white/10 text-white font-bold text-xs transition active:scale-95 flex items-center justify-center gap-2 shrink-0 shadow-sm"
      >
        <span>🔄</span>
        <span>Ganti Identitas Siswa</span>
      </button>
    </div>

    <!-- Interactive Mobile-Optimized Status Tabs & Filters -->
    <div class="bg-slate-900/80 backdrop-blur-xl rounded-2xl sm:rounded-3xl p-3.5 sm:p-5 border border-white/10 shadow-xl space-y-3.5">
      
      <!-- 1. Horizontal Status Pills (Tuntas, Sedang Belajar, Belum Dibaca) -->
      <div class="flex items-center gap-2 overflow-x-auto pb-1.5 scrollbar-none -mx-1 px-1 text-xs">
        <button
          @click="selectedStatus = 'Semua'"
          type="button"
          class="px-3.5 py-2 rounded-xl font-extrabold whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 min-h-[38px]"
          :class="selectedStatus === 'Semua' 
            ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black shadow-md shadow-cyan-500/25 ring-2 ring-cyan-400/40' 
            : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/5'"
        >
          <span>Semua Materi</span>
          <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono" :class="selectedStatus === 'Semua' ? 'bg-slate-950/30 text-white' : 'bg-white/10 text-gray-400'">
            {{ materiCounts.total }}
          </span>
        </button>

        <button
          @click="selectedStatus = 'belum_baca'"
          type="button"
          class="px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 min-h-[38px]"
          :class="selectedStatus === 'belum_baca' 
            ? 'bg-slate-200 text-slate-950 font-black shadow-md ring-2 ring-white/50' 
            : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/5'"
        >
          <span>⚪ Belum Dibaca</span>
          <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono" :class="selectedStatus === 'belum_baca' ? 'bg-slate-950/30 text-slate-900' : 'bg-white/10 text-gray-400'">
            {{ materiCounts.belum }}
          </span>
        </button>

        <button
          @click="selectedStatus = 'sedang_membaca'"
          type="button"
          class="px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 min-h-[38px]"
          :class="selectedStatus === 'sedang_membaca' 
            ? 'bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/25 ring-2 ring-amber-300' 
            : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/5'"
        >
          <span>⏳ Sedang Belajar</span>
          <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono" :class="selectedStatus === 'sedang_membaca' ? 'bg-slate-950/30 text-slate-900' : 'bg-white/10 text-gray-400'">
            {{ materiCounts.sedang }}
          </span>
        </button>

        <button
          @click="selectedStatus = 'selesai'"
          type="button"
          class="px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 shrink-0 min-h-[38px]"
          :class="selectedStatus === 'selesai' 
            ? 'bg-emerald-400 text-slate-950 font-black shadow-md shadow-emerald-400/25 ring-2 ring-emerald-300' 
            : 'bg-white/5 hover:bg-white/10 text-gray-300 border border-white/5'"
        >
          <span>✓ Tuntas</span>
          <span class="px-1.5 py-0.5 rounded-full text-[10px] font-mono" :class="selectedStatus === 'selesai' ? 'bg-slate-950/30 text-slate-900' : 'bg-white/10 text-gray-400'">
            {{ materiCounts.tuntas }}
          </span>
        </button>
      </div>

      <!-- 2. Horizontal Mapel Chips (If more than 1 mapel available) -->
      <div v-if="availableMapels.length > 1" class="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none -mx-1 px-1">
        <span class="text-[10px] uppercase font-mono font-bold text-gray-400 mr-1 shrink-0">Mapel:</span>
        <button
          @click="selectedMapel = 'Semua'"
          type="button"
          class="px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition shrink-0"
          :class="selectedMapel === 'Semua' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 font-bold' : 'bg-white/5 text-gray-400 hover:text-white border border-transparent'"
        >
          Semua Mapel
        </button>
        <button
          v-for="mpl in availableMapels"
          :key="mpl"
          @click="selectedMapel = mpl"
          type="button"
          class="px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition shrink-0"
          :class="selectedMapel === mpl ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 font-bold' : 'bg-white/5 text-gray-400 hover:text-white border border-transparent'"
        >
          {{ mpl }}
        </button>
      </div>

      <!-- 3. Search and Dropdown Controls -->
      <div class="grid grid-cols-1 sm:grid-cols-12 gap-2.5 pt-1 border-t border-white/5">
        <!-- Search Input with clear button -->
        <div class="sm:col-span-6 relative">
          <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 text-xs">🔍</span>
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Cari materi, judul, mapel..."
            class="w-full pl-9 pr-8 py-2.5 bg-slate-950 border border-white/15 rounded-xl text-xs text-white placeholder-slate-400 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 outline-none transition min-h-[42px]"
          />
          <button
            v-if="searchQuery"
            @click="searchQuery = ''"
            type="button"
            class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-white text-xs"
            title="Hapus pencarian"
          >
            ✕
          </button>
        </div>

        <!-- Semester Select -->
        <div class="sm:col-span-3">
          <select
            v-model="selectedSemester"
            class="w-full bg-slate-950 border border-white/15 rounded-xl px-3 py-2.5 text-xs text-cyan-300 font-bold focus:border-cyan-400 outline-none min-h-[42px]"
          >
            <option value="Ganjil">📅 Sem. Ganjil (1)</option>
            <option value="Genap">📅 Sem. Genap (2)</option>
            <option value="Semua">📅 Semua Semester</option>
          </select>
        </div>

        <!-- Format / Tipe Select -->
        <div class="sm:col-span-3">
          <select
            v-model="selectedTipe"
            class="w-full bg-slate-950 border border-white/15 rounded-xl px-3 py-2.5 text-xs text-white font-medium focus:border-cyan-400 outline-none min-h-[42px]"
          >
            <option value="Semua">📦 Semua Format</option>
            <option value="Slider PPT">🖥️ Slider PPT</option>
            <option value="Dokumen PDF/PPT">📄 Dokumen / PDF</option>
            <option value="Video YouTube">🎥 Video Belajar</option>
          </select>
        </div>
      </div>

      <!-- Quick Reset Link if filters applied -->
      <div v-if="selectedSemester !== 'Semua' || selectedTipe !== 'Semua' || selectedMapel !== 'Semua' || selectedStatus !== 'Semua' || searchQuery" class="flex items-center justify-between text-xs text-slate-400 pt-1">
        <span>Filter aktif (menampilkan {{ filteredMateri.length }} dari {{ props.materiList.length }} materi)</span>
        <button
          @click="resetFilters"
          type="button"
          class="text-cyan-400 hover:underline font-bold"
        >
          Reset Semua Filter ✕
        </button>
      </div>
    </div>

    <!-- Materi Cards Grid -->
    <div v-if="filteredMateri.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
      <div
        v-for="m in filteredMateri"
        :key="m.id"
        class="bg-slate-900/85 backdrop-blur-xl rounded-2xl sm:rounded-3xl border border-white/10 p-4 sm:p-5 flex flex-col justify-between hover:border-cyan-500/50 hover:shadow-2xl hover:shadow-cyan-500/10 transition-all duration-300 group shadow-lg"
      >
        <div>
          <!-- Card Header & Badges -->
          <div class="flex items-center justify-between gap-2 mb-2.5">
            <div class="flex items-center gap-1.5 flex-wrap">
              <span class="text-[10px] sm:text-[11px] font-black uppercase px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-full border tracking-wider"
                :class="m.tipe === 'Slider PPT' ? 'bg-cyan-500/15 border-cyan-500/30 text-cyan-300' : (m.tipe === 'Video YouTube' ? 'bg-rose-500/15 border-rose-500/30 text-rose-300' : 'bg-amber-500/15 border-amber-500/30 text-amber-300')"
              >
                {{ m.tipe === 'Slider PPT' ? '🖥️ Slide PPT' : (m.tipe === 'Video YouTube' ? '🎥 Video' : '📄 Dokumen') }}
              </span>
              <span v-if="m.tpKode" class="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[9px] sm:text-[10px] font-black px-2 py-0.5 rounded-full font-mono">
                {{ m.tpKode }}
              </span>
            </div>

            <span class="text-xs font-mono font-bold text-gray-400 truncate max-w-[130px] text-right">
              {{ m.mapel || 'Mapel' }}
            </span>
          </div>

          <!-- Title -->
          <h3 class="text-sm sm:text-base font-black text-white group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug mb-1.5">
            {{ m.judul }}
          </h3>

          <!-- Deskripsi -->
          <p class="text-[11px] sm:text-xs text-gray-400 line-clamp-2 leading-relaxed mb-3">
            {{ m.deskripsi || 'Tidak ada deskripsi singkat.' }}
          </p>

          <!-- Linked CBT Exam Badge -->
          <div v-if="m.cbtJadwal" class="mb-3">
            <div class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] sm:text-[11px] font-extrabold bg-indigo-500/20 text-indigo-300 border border-indigo-500/35 shadow-sm max-w-full">
              <span class="shrink-0">🎯 Ujian CBT:</span>
              <span class="truncate">{{ m.cbtJadwal.judul }}</span>
            </div>
          </div>

          <!-- Status Belajar Siswa Aktif -->
          <div class="bg-slate-950/70 rounded-xl sm:rounded-2xl p-2.5 sm:p-3 border border-white/5 space-y-1.5 mb-3.5">
            <div class="flex items-center justify-between text-[10px] sm:text-[11px]">
              <span class="text-gray-400 font-medium">Status Anda:</span>
              <span
                class="font-black"
                :class="getStudentReadStatus(m).status === 'selesai' ? 'text-emerald-400' : (getStudentReadStatus(m).status === 'sedang_membaca' ? 'text-amber-400' : 'text-gray-400')"
              >
                {{ getStudentReadStatus(m).status === 'selesai' ? '✓ Tuntas' : (getStudentReadStatus(m).status === 'sedang_membaca' ? '⏳ Sedang Belajar (' + getStudentReadStatus(m).progress + '%)' : '⚪ Belum Dibaca') }}
              </span>
            </div>

            <!-- Progress Bar -->
            <div class="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                class="h-full rounded-full transition-all duration-300"
                :class="getStudentReadStatus(m).status === 'selesai' ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]' : 'bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]'"
                :style="{ width: getStudentReadStatus(m).progress + '%' }"
              ></div>
            </div>
          </div>
        </div>

        <!-- Action Open Button -->
        <button
          @click="openMateri(m)"
          type="button"
          class="w-full py-2.5 sm:py-3 px-4 rounded-xl sm:rounded-2xl bg-gradient-to-r from-cyan-500 via-teal-600 to-indigo-600 text-white font-black text-xs shadow-lg shadow-cyan-500/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 min-h-[44px]"
        >
          <span>Buka Materi Pembelajaran</span>
          <span>➔</span>
        </button>
      </div>
    </div>

    <!-- Empty State -->
    <div v-else class="bg-slate-900/60 backdrop-blur-xl rounded-2xl sm:rounded-3xl border border-white/10 p-8 sm:p-12 text-center space-y-3">
      <div class="text-4xl">📚</div>
      <h3 class="text-base font-black text-white">Belum Ada Materi Pembelajaran</h3>
      <p class="text-xs text-gray-400 max-w-sm mx-auto">
        Materi belum diunggah atau tidak cocok dengan filter pencarian Anda.
      </p>
      <button
        v-if="selectedSemester !== 'Semua' || selectedTipe !== 'Semua' || selectedMapel !== 'Semua' || selectedStatus !== 'Semua' || searchQuery"
        @click="resetFilters"
        type="button"
        class="mt-2 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold text-xs hover:bg-cyan-500/30 transition"
      >
        <span>Reset Filter Pencarian</span>
      </button>
    </div>

    <!-- ======================================================== -->
    <!-- MODAL 1: SWITCH STUDENT IDENTITY MODAL (SHARED ACCOUNT) -->
    <!-- ======================================================== -->
    <Teleport to="body">
      <div
        v-if="showIdentityModal"
        class="fixed inset-0 z-[9990] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      >
      <div class="bg-slate-900 border border-white/10 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
        <div class="flex items-center justify-between border-b border-white/10 pb-4">
          <div class="flex items-center gap-2.5">
            <span class="text-2xl">👤</span>
            <div>
              <h3 class="text-base font-black text-white">Pilih Nama Anda</h3>
              <p class="text-[11px] text-gray-400">Akun bersama kelas — pilih nama Anda sebelum membaca</p>
            </div>
          </div>
          <button
            v-if="activeSiswa"
            @click="showIdentityModal = false"
            class="text-gray-400 hover:text-white text-lg font-bold"
          >✕</button>
        </div>

        <!-- Search Input -->
        <div>
          <input
            v-model="studentSearchQuery"
            type="text"
            placeholder="Ketik nama atau NIS Anda..."
            class="w-full bg-slate-800 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white placeholder-gray-400 focus:border-cyan-400 outline-none"
            autofocus
          />
        </div>

        <!-- Student List -->
        <div class="max-h-60 overflow-y-auto space-y-2 pr-1">
          <button
            v-for="s in filteredSiswaList"
            :key="s.id"
            @click="selectStudent(s)"
            type="button"
            class="w-full p-3 rounded-2xl border text-left transition flex items-center justify-between group"
            :class="String(s.id) === String(activeSiswaId) ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-200' : 'bg-slate-800/60 border-white/5 text-gray-300 hover:bg-slate-800 hover:border-white/20'"
          >
            <div class="min-w-0 pr-2">
              <div class="text-xs font-black truncate group-hover:text-white">{{ s.nama }}</div>
              <div class="text-[10px] text-gray-400 font-mono">NIS: {{ s.nis || '-' }} · Absen: {{ s.absen || '-' }}</div>
            </div>
            <span v-if="String(s.id) === String(activeSiswaId)" class="text-xs text-cyan-400 font-bold shrink-0">✓ Aktif</span>
          </button>
        </div>

        <div class="text-center pt-2">
          <p class="text-[11px] text-gray-400">
            Nama ini akan dicatat guru sebagai bukti kehadiran membaca materi & tugas.
          </p>
        </div>
      </div>
    </div>
    </Teleport>

    <!-- ======================================================== -->
    <!-- FULLSCREEN IMMERSIVE PRESENTATION STAGE (16:9 EXECUTIVE CANVAS) -->
    <!-- ======================================================== -->
    <Teleport to="body">
      <div
        v-if="showReader && activeMateri"
        class="fixed inset-0 w-full h-full z-[9999] flex flex-col overflow-hidden transition-colors duration-300"
        :class="currentThemeClass.bg"
        style="overscroll-behavior: contain; touch-action: pan-y;"
        @touchstart.passive="handleTouchStart"
        @touchend.passive="handleTouchEnd"
      >
      <!-- TOP HUD PRESENTATION BAR -->
      <header
        class="border-b px-3 sm:px-8 py-2 sm:py-3 flex items-center justify-between gap-2 sm:gap-4 backdrop-blur-xl shrink-0 z-30"
        :class="currentThemeClass.header"
      >
        <!-- Left: Exit, Title, Identity -->
        <div class="flex items-center gap-2 sm:gap-4 min-w-0 flex-1">
          <button
            @click="closeReader"
            type="button"
            class="px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl sm:rounded-2xl bg-white/10 hover:bg-white/20 text-xs font-black transition flex items-center gap-1.5 active:scale-95 text-white shadow-sm shrink-0"
            title="Tutup Reader & Kembali ke Dashboard"
          >
            <span>✕</span>
            <span class="hidden sm:inline">Keluar</span>
          </button>

          <div class="min-w-0 flex-1">
            <h2 class="text-xs sm:text-base font-black truncate leading-tight flex items-center gap-1.5 sm:gap-2">
              <span class="hidden md:inline-block px-2 py-0.5 rounded-lg text-[10px] uppercase font-mono font-bold tracking-wider shrink-0" :class="currentThemeClass.badge">
                {{ activeMateri.tipe }}
              </span>
              <span class="truncate">{{ activeMateri.judul }}</span>
            </h2>
            <div class="text-[10px] sm:text-[11px] text-slate-400 truncate flex items-center gap-2 mt-0.5">
              <span v-if="activeSiswa" class="font-bold text-cyan-400 truncate">
                👤 {{ activeSiswa.nama }}
              </span>
              <span v-if="activeMateri.tipe === 'Slider PPT'" class="font-mono text-gray-400 shrink-0">
                · {{ currentSlideIndex + 1 }}/{{ currentSlides.length }}
              </span>
            </div>
          </div>
        </div>

        <!-- Right: Theme Picker, Fullscreen Toggle, Complete / CBT -->
        <div class="flex items-center gap-1 sm:gap-2.5 shrink-0">
          <!-- Mobile Quick Slide Pager -->
          <div v-if="activeMateri.tipe === 'Slider PPT' && currentSlides.length > 1" class="flex sm:hidden items-center gap-0.5 bg-white/10 p-0.5 rounded-xl border border-white/15 shrink-0">
            <button
              @click="prevSlide"
              :disabled="currentSlideIndex === 0"
              type="button"
              class="w-7 h-7 rounded-lg flex items-center justify-center text-[10px] font-black text-white hover:bg-white/20 disabled:opacity-20 active:scale-90 transition"
              title="Slide Sebelumnya"
            >
              ◀
            </button>
            <span class="text-[10px] font-mono font-black text-cyan-300 px-1 whitespace-nowrap">
              {{ currentSlideIndex + 1 }}/{{ currentSlides.length }}
            </span>
            <button
              @click="nextSlide"
              :disabled="currentSlideIndex === currentSlides.length - 1"
              type="button"
              class="w-7 h-7 rounded-lg flex items-center justify-center text-[10px] font-black text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-20 active:scale-90 transition shadow"
              title="Slide Berikutnya"
            >
              ▶
            </button>
          </div>

          <!-- Live Theme Switcher for Slider PPT -->
          <div v-if="activeMateri.tipe === 'Slider PPT'" class="hidden md:flex items-center gap-1 bg-white/5 p-1 rounded-2xl border border-white/10">
            <button
              v-for="(tObj, tKey) in THEME_STYLES"
              :key="tKey"
              @click="userSelectedTheme = tKey"
              type="button"
              class="w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold transition-all"
              :class="activeTheme === tKey ? 'scale-110 shadow ring-2 ring-cyan-400 ' + tObj.accentBg : 'opacity-60 hover:opacity-100'"
              :title="'Ganti Tema: ' + tKey"
            >
              {{ tKey === 'dark' ? '⚡' : (tKey === 'light' ? '🎨' : (tKey === 'aurora' ? '🌅' : (tKey === 'navy' ? '🌊' : (tKey === 'emerald' ? '🍃' : '💎')))) }}
            </button>
          </div>

          <!-- Auto-Play Slideshow Toggle -->
          <button
            v-if="activeMateri.tipe === 'Slider PPT' && currentSlides.length > 1"
            @click="toggleAutoPlay"
            type="button"
            class="hidden sm:flex px-2.5 py-1.5 rounded-2xl text-xs font-bold transition items-center gap-1.5 active:scale-95 border"
            :class="isAutoPlaying
              ? 'bg-cyan-400 text-slate-950 border-cyan-300 shadow-md font-black ring-2 ring-cyan-300'
              : 'bg-white/10 hover:bg-white/20 text-white border-white/10'"
            :title="isAutoPlaying ? 'Jeda Putar Otomatis' : 'Putar Slide Otomatis (5 detik)'"
          >
            <span>{{ isAutoPlaying ? '⏸' : '▶' }}</span>
            <span class="hidden lg:inline">{{ isAutoPlaying ? 'Jeda' : 'Auto' }}</span>
          </button>

          <!-- Native Fullscreen Toggle -->
          <button
            @click="toggleBrowserFullscreen"
            type="button"
            class="hidden sm:flex w-9 h-9 rounded-2xl bg-white/10 hover:bg-white/20 text-white items-center justify-center text-sm transition active:scale-95"
            title="Layar Penuh (F)"
          >
            {{ isFullscreenMode ? '🗗' : '⛶' }}
          </button>

          <!-- Complete Button -->
          <button
            v-if="!isCompletedForActiveSiswa"
            @click="markCompleted"
            :disabled="isMarkingComplete"
            type="button"
            class="px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl sm:rounded-2xl text-xs font-black bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition active:scale-95 shadow-md flex items-center gap-1 sm:gap-1.5 disabled:opacity-50 shrink-0"
          >
            <span>✓</span>
            <span class="hidden sm:inline">Tandai Selesai</span>
          </button>
          <span
            v-else
            class="px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl sm:rounded-2xl text-[10px] sm:text-[11px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 sm:gap-1.5 shrink-0"
          >
            <span>✓</span>
            <span class="hidden sm:inline">Tuntas Dibaca</span>
          </span>

          <!-- Linked CBT Exam Button -->
          <button
            v-if="activeMateri.cbtJadwal"
            @click="jumpToCbt"
            type="button"
            class="hidden sm:flex px-4 py-2 rounded-2xl text-xs font-black bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/30 transition hover:scale-105 active:scale-95 items-center gap-1.5 shrink-0"
            title="Lanjut ke Ujian CBT"
          >
            <span>🎯</span>
            <span class="hidden md:inline">Lanjut Ujian CBT</span>
          </button>
        </div>
      </header>

      <!-- Reading Progress Bar -->
      <div v-if="activeMateri.tipe === 'Slider PPT'" class="w-full h-1.5 bg-white/10 shrink-0">
        <div
          class="h-full bg-gradient-to-r from-cyan-400 to-teal-400 transition-all duration-300 shadow-sm"
          :style="{ width: slideProgressPercent + '%' }"
        ></div>
      </div>

      <!-- MAIN READER STAGE -->
      <main class="flex-1 min-h-0 overflow-y-auto p-2.5 sm:p-6 lg:p-8 pb-40 sm:pb-36 flex flex-col items-center justify-start relative scroll-smooth overscroll-y-contain w-full max-w-full overflow-x-hidden">

        <!-- ============================================== -->
        <!-- 1. SLIDER PPT: EXECUTIVE WIDESCREEN PRESENTATION -->
        <!-- ============================================== -->
        <div
          v-if="activeMateri.tipe === 'Slider PPT' && currentSlide"
          class="w-full max-w-6xl mx-auto flex flex-col items-center justify-center relative py-1 sm:py-2"
        >
          <!-- Floating Left Arrow Button -->
          <button
            v-if="currentSlides.length > 1 && currentSlideIndex > 0"
            @click="prevSlide"
            type="button"
            class="hidden sm:flex absolute left-1 sm:left-2 lg:-left-8 top-1/2 -translate-y-1/2 z-20 w-9 h-9 sm:w-12 sm:h-12 rounded-full bg-slate-900/85 hover:bg-slate-800 text-white border border-white/25 items-center justify-center text-xs sm:text-lg font-black shadow-2xl transition-all duration-200 hover:scale-110 active:scale-90 backdrop-blur-md"
            title="Slide Sebelumnya (◄)"
          >
            ❮
          </button>

          <!-- Floating Right Arrow Button -->
          <button
            v-if="currentSlides.length > 1 && currentSlideIndex < currentSlides.length - 1"
            @click="nextSlide"
            type="button"
            class="hidden sm:flex absolute right-1 sm:right-2 lg:-right-8 top-1/2 -translate-y-1/2 z-20 w-9 h-9 sm:w-12 sm:h-12 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 items-center justify-center text-xs sm:text-lg font-black shadow-2xl shadow-cyan-500/40 transition-all duration-200 hover:scale-110 active:scale-90"
            title="Slide Berikutnya (►)"
          >
            ❯
          </button>

          <!-- THE 16:9 SLIDE CANVAS CONTAINER -->
          <div
            class="w-full max-w-full rounded-2xl sm:rounded-3xl border p-3.5 sm:p-8 lg:p-12 transition-all duration-300 relative overflow-hidden flex flex-col justify-between min-h-0 sm:min-h-[460px] lg:min-h-[540px]"
            :class="currentThemeClass.card"
          >
            <!-- Ambient Glow Decoration -->
            <div
              class="pointer-events-none absolute -top-32 -left-32 w-80 h-80 rounded-full blur-3xl opacity-30"
              :style="{ backgroundColor: currentThemeClass.glow }"
            ></div>
            <div
              class="pointer-events-none absolute -bottom-32 -right-32 w-80 h-80 rounded-full blur-3xl opacity-20"
              :style="{ backgroundColor: currentThemeClass.glow }"
            ></div>

            <!-- SLIDE CONTENT WITH CANVA DIRECTIONAL SLIDER TRANSITION -->
            <Transition :name="slideTransition" mode="out-in">
              <div :key="currentSlideIndex" class="relative z-10 flex flex-col justify-between flex-1 w-full min-h-0">
                <!-- SLIDE TOP META HEADER -->
                <div class="flex items-center justify-between gap-4 border-b border-white/10 pb-4 mb-6">
              <!-- Label Pill -->
              <div class="flex items-center gap-2.5">
                <span
                  class="text-xs font-black uppercase tracking-wider px-3.5 py-1.5 rounded-full border shadow-sm flex items-center gap-1.5"
                  :class="currentThemeClass.badge"
                >
                  <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                  <span>{{ (currentSlide.label && currentSlide.label !== 'Apersepsi') ? currentSlide.label : (activeMateri.mapel || 'Materi Pembelajaran') }}</span>
                </span>
                <span v-if="currentSlide.label && currentSlide.label !== 'Apersepsi'" class="text-[11px] font-mono text-gray-400 hidden sm:inline">
                  {{ activeMateri.mapel || 'Informatika' }}
                </span>
              </div>

              <!-- Slide Number Counter -->
              <div class="flex items-center gap-3">
                <span class="text-xs font-mono font-extrabold px-3 py-1 rounded-xl bg-white/10 text-white border border-white/10">
                  SLIDE {{ String(currentSlideIndex + 1).padStart(2, '0') }} / {{ String(currentSlides.length).padStart(2, '0') }}
                </span>
              </div>
            </div>

            <!-- SLIDE MAIN CONTENT AREA -->
            <div class="relative z-10 flex-1">
              <!-- Slide Title -->
              <h3 class="text-xl sm:text-3xl lg:text-4xl font-black mb-4 sm:mb-6 leading-tight tracking-tight text-white drop-shadow-sm">
                {{ currentSlide.judul }}
              </h3>

              <!-- LAYOUT A: Standard (Text, Markdown Tables, Formulas) -->
              <div v-if="currentSlide.layout === 'standard'" class="space-y-6">
                <div v-if="currentSlide.fileUrl" class="max-w-2xl mx-auto rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-black/40">
                  <img :src="currentSlide.fileUrl" class="w-full object-contain max-h-80" />
                </div>

                <!-- Rich Markdown & Math Content -->
                <div
                  class="slide-markdown-content text-sm sm:text-base leading-relaxed"
                  v-html="renderFormulaContent(currentSlide.konten)"
                ></div>
              </div>

              <!-- LAYOUT B: Image Left + Content Right -->
              <div v-else-if="currentSlide.layout === 'image_left'" class="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                <div v-if="currentSlide.fileUrl" class="md:col-span-5 rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-black/40">
                  <img :src="currentSlide.fileUrl" class="w-full object-contain max-h-96" />
                </div>
                <div
                  :class="currentSlide.fileUrl ? 'md:col-span-7' : 'md:col-span-12'"
                  class="slide-markdown-content text-sm sm:text-base leading-relaxed"
                  v-html="renderFormulaContent(currentSlide.konten)"
                ></div>
              </div>

              <!-- LAYOUT C: Content Left + Image Right -->
              <div v-else-if="currentSlide.layout === 'image_right'" class="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                <div
                  :class="currentSlide.fileUrl ? 'md:col-span-7' : 'md:col-span-12'"
                  class="slide-markdown-content text-sm sm:text-base leading-relaxed order-2 md:order-1"
                  v-html="renderFormulaContent(currentSlide.konten)"
                ></div>
                <div v-if="currentSlide.fileUrl" class="md:col-span-5 rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-black/40 order-1 md:order-2">
                  <img :src="currentSlide.fileUrl" class="w-full object-contain max-h-96" />
                </div>
              </div>

              <!-- LAYOUT D: Highlight Box (Formula / Takeaways) -->
              <div v-else class="space-y-6">
                <div
                  class="p-6 sm:p-8 rounded-3xl border shadow-xl relative overflow-hidden backdrop-blur-sm"
                  :class="currentThemeClass.highlightBox"
                >
                  <div
                    class="slide-markdown-content text-base sm:text-lg font-medium leading-relaxed"
                    v-html="renderFormulaContent(currentSlide.konten)"
                  ></div>
                </div>

                <div v-if="currentSlide.fileUrl" class="max-w-xl mx-auto rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-black/40">
                  <img :src="currentSlide.fileUrl" class="w-full object-contain max-h-72" />
                </div>
              </div>
            </div>

            <!-- SLIDE FOOTER BANNER ON LAST SLIDE -->
            <div
              v-if="currentSlideIndex === currentSlides.length - 1"
              class="relative z-10 mt-8 p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-teal-950/60 to-indigo-950/70 border border-emerald-500/40 text-center space-y-3 shadow-2xl"
            >
              <div class="text-3xl">🎉</div>
              <h4 class="text-base sm:text-lg font-black text-white">Luar Biasa! Anda Telah Membaca Semua Slide</h4>
              <p class="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
                Tuntaskan sesi belajar Anda dengan konfirmasi penyelesaian materi untuk membuka Token Ujian CBT.
              </p>

              <!-- CBT TOKEN BOX (HANYA MUNCUL DI MATERI) -->
              <div v-if="activeMateri.cbtJadwal" class="mt-4 p-4 rounded-2xl bg-slate-950/80 border border-cyan-500/30 max-w-md mx-auto space-y-3">
                <div class="flex items-center justify-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span class="text-xs font-black uppercase text-cyan-300">Ujian CBT Terkait: {{ activeMateri.cbtJadwal.judul }}</span>
                </div>

                <div v-if="isCompletedForActiveSiswa && activeMateri.cbtJadwal.token" class="space-y-2">
                  <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">KUNCI AKSES TOKEN UJIAN:</span>
                  <div class="flex items-center justify-center gap-2">
                    <span class="px-4 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 font-mono font-black text-xl border border-cyan-400/40 tracking-widest shadow-inner">
                      {{ activeMateri.cbtJadwal.token }}
                    </span>
                    <button
                      @click="copyToken(activeMateri.cbtJadwal.token)"
                      type="button"
                      class="px-3 py-2 rounded-xl bg-cyan-500 text-slate-950 font-black text-xs hover:bg-cyan-400 transition"
                      title="Salin Token"
                    >
                      {{ isCopiedToken ? 'Tersalin ✓' : 'Salin Token 📋' }}
                    </button>
                  </div>
                  <p class="text-[11px] text-emerald-300 font-medium">
                    ✓ Selamat! Anda telah menyelesaikan materi dan Token Ujian resmi terbuka.
                  </p>
                </div>

                <div v-else class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center justify-center gap-2">
                  <span>🔒</span>
                  <span>Token Ujian terkunci. Tekan tombol <strong>"Konfirmasi Selesai Membaca"</strong> untuk membuka Token.</span>
                </div>
              </div>

              <div class="flex items-center justify-center gap-3 pt-2 flex-wrap">
                <button
                  v-if="!isCompletedForActiveSiswa"
                  @click="markCompleted"
                  :disabled="isMarkingComplete"
                  type="button"
                  class="px-6 py-2.5 rounded-2xl bg-emerald-500 text-slate-950 font-black text-xs hover:bg-emerald-400 active:scale-95 transition shadow-lg shadow-emerald-500/25 flex items-center gap-2"
                >
                  <span>✓</span>
                  <span>Konfirmasi Selesai Membaca (Buka Token CBT)</span>
                </button>

                <button
                  v-if="activeMateri.cbtJadwal && isCompletedForActiveSiswa"
                  @click="jumpToCbtWithToken(activeMateri.cbtJadwal)"
                  type="button"
                  class="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-black text-xs hover:scale-105 active:scale-95 transition shadow-lg shadow-indigo-500/30 flex items-center gap-2"
                >
                  <span>🎯 Lanjut Kerjakan Ujian CBT Sekarang</span>
                  <span>➔</span>
                </button>
              </div>
            </div>
          </div>
        </Transition>

            <!-- SLIDE CANVAS BOTTOM META -->
            <div class="relative z-10 flex items-center justify-between border-t border-white/10 pt-4 mt-6 text-[11px] text-gray-400">
              <span class="font-mono">SMKS Muhammadiyah 2 Genteng</span>
              <span class="hidden sm:inline font-mono">Gunakan tombol ◄ ► atau Spasi untuk berpindah slide</span>
              <span class="font-mono">TP: {{ activeMateri.tp?.judul ? activeMateri.tp.judul.substring(0, 35) + '...' : 'Kurikulum Merdeka' }}</span>
            </div>
          </div>

          <!-- Mobile Bottom Slide Nav Toolbar (Thumb Friendly) -->
          <div v-if="currentSlides.length > 1" class="sm:hidden flex items-center justify-between gap-2.5 w-full mt-3 px-1 shrink-0">
            <button
              @click="prevSlide"
              :disabled="currentSlideIndex === 0"
              type="button"
              class="flex-1 py-3 px-3 rounded-2xl bg-white/10 hover:bg-white/20 disabled:opacity-20 text-white font-bold text-xs border border-white/15 flex items-center justify-center gap-1.5 active:scale-95 transition min-h-[44px]"
            >
              <span>❮</span>
              <span>Sebelumnya</span>
            </button>
            <span class="text-xs font-mono font-black text-cyan-300 px-3 py-2 rounded-xl bg-slate-900 border border-white/10 shrink-0">
              {{ currentSlideIndex + 1 }} / {{ currentSlides.length }}
            </span>
            <button
              @click="nextSlide"
              :disabled="currentSlideIndex === currentSlides.length - 1"
              type="button"
              class="flex-1 py-3 px-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 font-black text-xs shadow-lg shadow-cyan-500/25 active:scale-95 transition min-h-[44px] flex items-center justify-center gap-1.5"
            >
              <span>Selanjutnya</span>
              <span>❯</span>
            </button>
          </div>
        </div>

        <!-- ============================================== -->
        <!-- 2. VIDEO YOUTUBE EMBED -->
        <!-- ============================================== -->
        <div
          v-else-if="activeMateri.tipe === 'Video YouTube'"
          class="w-full max-w-4xl mx-auto space-y-6"
        >
          <div class="aspect-video w-full rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-black">
            <iframe
              v-if="youtubeEmbedUrl"
              :src="youtubeEmbedUrl"
              class="w-full h-full"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
            <div v-else class="w-full h-full flex flex-col items-center justify-center text-center p-6 text-gray-400 space-y-3">
              <div class="text-4xl">⚠️</div>
              <p class="text-sm font-bold text-white">Tautan video YouTube tidak valid.</p>
              <a :href="activeMateri.fileUrl" target="_blank" class="text-xs text-cyan-400 underline">Buka tautan asli di tab baru</a>
            </div>
          </div>

          <div class="bg-slate-900/90 rounded-3xl p-6 border border-white/10 space-y-3">
            <h3 class="text-lg font-black text-white">Deskripsi Video Pembelajaran</h3>
            <p class="text-sm text-gray-300 leading-relaxed">{{ activeMateri.deskripsi || 'Simak video hingga selesai untuk memahami materi.' }}</p>
          </div>

          <!-- Video Completion & CBT Token Section -->
          <div class="bg-slate-900/90 rounded-3xl p-6 border border-white/10 space-y-4">
            <div class="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h4 class="text-sm font-bold text-white flex items-center gap-2">
                  <span>{{ isCompletedForActiveSiswa ? '✓ Status: Selesai Disimak' : '⏳ Status: Sedang Dipelajari' }}</span>
                </h4>
                <p class="text-xs text-gray-400 mt-0.5">
                  {{ isCompletedForActiveSiswa ? 'Kehadiran dan catatan baca Anda telah tercatat otomatis di sistem absensi guru.' : 'Tekan tombol konfirmasi setelah Anda selesai menyimak video.' }}
                </p>
              </div>

              <button
                v-if="!isCompletedForActiveSiswa"
                @click="markCompleted"
                :disabled="isMarkingComplete"
                type="button"
                class="px-5 py-2.5 rounded-2xl bg-emerald-500 text-slate-950 font-black text-xs hover:bg-emerald-400 active:scale-95 transition shadow-lg shadow-emerald-500/25 flex items-center gap-2"
              >
                <span>✓</span>
                <span>Konfirmasi Selesai Menyimak</span>
              </button>
            </div>

            <!-- CBT Token Box if linked to CBT -->
            <div v-if="activeMateri.cbtJadwal" class="pt-4 border-t border-white/10 space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-cyan-300 flex items-center gap-2">
                  <span>🎯</span>
                  <span>Ujian CBT Terkait: {{ activeMateri.cbtJadwal.judul }}</span>
                </span>
                <span class="text-[11px] px-2 py-0.5 rounded-lg font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {{ activeMateri.cbtJadwal.durasi_menit }} Menit
                </span>
              </div>

              <div v-if="isCompletedForActiveSiswa" class="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-3">
                <div class="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <div class="text-[10px] uppercase font-bold tracking-wider text-emerald-400">Token Akses Ujian CBT</div>
                    <div class="text-xl font-mono font-black tracking-widest text-white mt-0.5">{{ activeMateri.cbtJadwal.token || 'TIDAK BUTUH TOKEN' }}</div>
                  </div>
                  <div class="flex items-center gap-2">
                    <button
                      v-if="activeMateri.cbtJadwal.token"
                      @click="copyToken(activeMateri.cbtJadwal.token)"
                      type="button"
                      class="px-3 py-2 rounded-xl bg-cyan-500 text-slate-950 font-black text-xs hover:bg-cyan-400 transition"
                    >
                      {{ isCopiedToken ? 'Tersalin ✓' : 'Salin Token 📋' }}
                    </button>
                    <button
                      @click="jumpToCbtWithToken(activeMateri.cbtJadwal)"
                      type="button"
                      class="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-black text-xs hover:scale-105 active:scale-95 transition shadow-lg shadow-indigo-500/30 flex items-center gap-1.5"
                    >
                      <span>Lanjut ke CBT</span>
                      <span>➔</span>
                    </button>
                  </div>
                </div>
              </div>

              <div v-else class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center justify-center gap-2">
                <span>🔒</span>
                <span>Token Ujian terkunci. Konfirmasi selesai menyimak video di atas untuk membuka Token CBT.</span>
              </div>
            </div>
          </div>
        </div>

        <!-- ============================================== -->
        <!-- 3. DOKUMEN / PDF VIEWER -->
        <!-- ============================================== -->
        <div
          v-else
          class="w-full max-w-5xl mx-auto space-y-6"
        >
          <div class="w-full h-[70vh] rounded-3xl overflow-hidden border border-white/15 shadow-2xl bg-slate-900">
            <iframe
              v-if="activeMateri.fileUrl"
              :src="activeMateri.fileUrl"
              class="w-full h-full"
              frameborder="0"
            ></iframe>
            <div v-else class="w-full h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div class="text-4xl">📄</div>
              <p class="text-sm font-bold text-white">Dokumen digital tidak memiliki tautan penampil langsung.</p>
              <a
                v-if="activeMateri.fileUrl || activeMateri.filePath"
                :href="activeMateri.fileUrl || ('/storage/' + activeMateri.filePath)"
                target="_blank"
                download
                class="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-md transition active:scale-95"
              >
                <span>📥 Unduh Berkas PDF / PPT</span>
              </a>
            </div>
          </div>

          <!-- Document Completion & CBT Token Section -->
          <div class="bg-slate-900/90 rounded-3xl p-6 border border-white/10 space-y-4">
            <div class="flex items-center justify-between flex-wrap gap-3">
              <div>
                <h4 class="text-sm font-bold text-white flex items-center gap-2">
                  <span>{{ isCompletedForActiveSiswa ? '✓ Status: Selesai Membaca Dokumen' : '⏳ Status: Sedang Membaca' }}</span>
                </h4>
                <p class="text-xs text-gray-400 mt-0.5">
                  {{ isCompletedForActiveSiswa ? 'Kehadiran dan catatan baca Anda telah tercatat otomatis di sistem absensi guru.' : 'Tekan tombol konfirmasi setelah Anda selesai membaca dokumen.' }}
                </p>
              </div>

              <button
                v-if="!isCompletedForActiveSiswa"
                @click="markCompleted"
                :disabled="isMarkingComplete"
                type="button"
                class="px-5 py-2.5 rounded-2xl bg-emerald-500 text-slate-950 font-black text-xs hover:bg-emerald-400 active:scale-95 transition shadow-lg shadow-emerald-500/25 flex items-center gap-2"
              >
                <span>✓</span>
                <span>Konfirmasi Selesai Membaca</span>
              </button>
            </div>

            <!-- CBT Token Box if linked to CBT -->
            <div v-if="activeMateri.cbtJadwal" class="pt-4 border-t border-white/10 space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-cyan-300 flex items-center gap-2">
                  <span>🎯</span>
                  <span>Ujian CBT Terkait: {{ activeMateri.cbtJadwal.judul }}</span>
                </span>
                <span class="text-[11px] px-2 py-0.5 rounded-lg font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {{ activeMateri.cbtJadwal.durasi_menit }} Menit
                </span>
              </div>

              <div v-if="isCompletedForActiveSiswa" class="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 space-y-3">
                <div class="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <div class="text-[10px] uppercase font-bold tracking-wider text-emerald-400">Token Akses Ujian CBT</div>
                    <div class="text-xl font-mono font-black tracking-widest text-white mt-0.5">{{ activeMateri.cbtJadwal.token || 'TIDAK BUTUH TOKEN' }}</div>
                  </div>
                  <div class="flex items-center gap-2">
                    <button
                      v-if="activeMateri.cbtJadwal.token"
                      @click="copyToken(activeMateri.cbtJadwal.token)"
                      type="button"
                      class="px-3 py-2 rounded-xl bg-cyan-500 text-slate-950 font-black text-xs hover:bg-cyan-400 transition"
                    >
                      {{ isCopiedToken ? 'Tersalin ✓' : 'Salin Token 📋' }}
                    </button>
                    <button
                      @click="jumpToCbtWithToken(activeMateri.cbtJadwal)"
                      type="button"
                      class="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-black text-xs hover:scale-105 active:scale-95 transition shadow-lg shadow-indigo-500/30 flex items-center gap-1.5"
                    >
                      <span>Lanjut ke CBT</span>
                      <span>➔</span>
                    </button>
                  </div>
                </div>
              </div>

              <div v-else class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-center justify-center gap-2">
                <span>🔒</span>
                <span>Token Ujian terkunci. Konfirmasi selesai membaca dokumen di atas untuk membuka Token CBT.</span>
              </div>
            </div>
          </div>
        </div>

      </main>

      <!-- BOTTOM PRESENTATION CONTROLS (FOR SLIDER PPT) -->
      <footer
        v-if="activeMateri.tipe === 'Slider PPT' && currentSlides.length > 1"
        class="fixed bottom-0 inset-x-0 z-50 border-t border-cyan-500/30 px-3 sm:px-8 py-2.5 sm:py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] flex items-center justify-between gap-2 sm:gap-4 backdrop-blur-2xl shadow-[0_-10px_35px_rgba(0,0,0,0.95)]"
        :class="currentThemeClass.header"
      >
        <!-- Prev Button -->
        <button
          @click="prevSlide"
          :disabled="currentSlideIndex === 0"
          type="button"
          class="px-3.5 sm:px-5 py-2 sm:py-2.5 rounded-xl sm:rounded-2xl bg-white/10 hover:bg-white/20 text-xs font-black transition disabled:opacity-25 active:scale-95 flex items-center gap-1.5 text-white shrink-0 min-h-[42px]"
          title="Slide Sebelumnya (◄)"
        >
          <span>◀</span>
          <span class="text-[11px] sm:text-xs">Sebelumnya</span>
        </button>

        <!-- Slide Indicators / Thumbnails + AutoPlay -->
        <div class="flex items-center gap-1.5 sm:gap-2 overflow-x-auto max-w-[200px] sm:max-w-md py-1 no-scrollbar">
          <button
            @click="toggleAutoPlay"
            type="button"
            class="px-2 py-1 rounded-xl text-[10px] font-bold border transition flex items-center gap-1 shrink-0"
            :class="isAutoPlaying ? 'bg-cyan-400 text-slate-950 border-cyan-300 font-black shadow-md shadow-cyan-400/30 ring-1 ring-cyan-300' : 'bg-white/10 hover:bg-white/20 text-white border-white/10'"
            :title="isAutoPlaying ? 'Jeda Putar Otomatis' : 'Putar Slide Otomatis (5 detik)'"
          >
            <span>{{ isAutoPlaying ? '⏸' : '▶' }}</span>
            <span class="hidden sm:inline">{{ isAutoPlaying ? 'Jeda' : 'Otomatis' }}</span>
          </button>
          <button
            v-for="(s, idx) in currentSlides"
            :key="idx"
            @click="goToSlide(idx)"
            type="button"
            class="h-2 sm:h-2.5 rounded-full transition-all duration-200 shrink-0"
            :class="currentSlideIndex === idx ? 'w-6 sm:w-10 bg-cyan-400 shadow-md shadow-cyan-400/50' : 'w-2 sm:w-2.5 bg-white/20 hover:bg-white/50'"
            :title="`Pindah ke slide ${idx + 1}: ${s.judul}`"
          ></button>
        </div>

        <!-- Next Button -->
        <button
          @click="nextSlide"
          :disabled="currentSlideIndex === currentSlides.length - 1"
          type="button"
          class="px-3.5 sm:px-5 py-2 sm:py-2.5 rounded-xl sm:rounded-2xl text-xs font-black transition disabled:opacity-25 active:scale-95 flex items-center gap-1.5 shadow-lg shrink-0 min-h-[42px]"
          :class="currentThemeClass.accentBg"
          title="Slide Berikutnya (►)"
        >
          <span class="text-[11px] sm:text-xs">Berikutnya</span>
          <span>▶</span>
        </button>
      </footer>
    </div>
    </Teleport>

  </div>
</template>

<style>
/* ========================================================
   PRESENTATION MARKDOWN & TABLES STYLING (EXECUTIVE DECK)
   ======================================================== */
.slide-markdown-content {
  color: inherit;
  overflow-wrap: break-word;
  word-break: break-word;
  max-width: 100%;
}

.slide-markdown-content p {
  margin-bottom: 1.25rem;
  line-height: 1.75;
  overflow-wrap: break-word;
  word-break: break-word;
}

.slide-markdown-content strong {
  color: #ffffff;
  font-weight: 800;
}

.slide-markdown-content em {
  font-style: italic;
  opacity: 0.9;
}

/* Presentation Table (Responsive with touch scroll) */
.slide-markdown-content table {
  width: 100%;
  max-width: 100%;
  display: block;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  border-collapse: separate;
  border-spacing: 0;
  margin: 1.25rem 0;
  border-radius: 1rem;
  border: 1px solid rgba(255, 255, 255, 0.15);
  background: rgba(15, 23, 42, 0.65);
  backdrop-filter: blur(12px);
  box-shadow: 0 15px 35px -5px rgba(0, 0, 0, 0.4);
}

.slide-markdown-content thead {
  background: rgba(2, 6, 23, 0.85);
  border-bottom: 2px solid rgba(6, 182, 212, 0.4);
}

.slide-markdown-content th {
  padding: 1rem 1.25rem;
  text-align: left;
  font-size: 0.75rem;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: 0.075em;
  color: #38bdf8;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.slide-markdown-content td {
  padding: 1rem 1.25rem;
  font-size: 0.875rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  vertical-align: middle;
}

.slide-markdown-content tbody tr:last-child td {
  border-bottom: none;
}

.slide-markdown-content tbody tr:nth-child(even) {
  background: rgba(255, 255, 255, 0.02);
}

.slide-markdown-content tbody tr:hover {
  background: rgba(6, 182, 212, 0.08);
}

/* Keyboard Shortcut & Code Badges */
.slide-markdown-content code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 0.8rem;
  font-weight: 700;
  padding: 0.25rem 0.6rem;
  border-radius: 0.5rem;
  background: rgba(30, 41, 59, 0.9);
  color: #38bdf8;
  border: 1px solid rgba(56, 189, 248, 0.35);
  box-shadow: inset 0 -2px 0 0 rgba(0, 0, 0, 0.4), 0 2px 4px rgba(0, 0, 0, 0.2);
  display: inline-block;
  white-space: pre-wrap;
  word-break: break-word;
  max-width: 100%;
}

.slide-markdown-content img {
  max-width: 100%;
  height: auto;
  object-fit: contain;
}

.slide-markdown-content .katex-display {
  max-width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  padding: 0.5rem 0;
  -webkit-overflow-scrolling: touch;
}

/* Headings inside slide */
.slide-markdown-content h1,
.slide-markdown-content h2,
.slide-markdown-content h3,
.slide-markdown-content h4 {
  font-weight: 900;
  margin-top: 1.5rem;
  margin-bottom: 0.75rem;
  color: #ffffff;
}

/* Lists styling */
.slide-markdown-content ul {
  list-style-type: none;
  padding-left: 0;
  margin: 1.25rem 0;
}

.slide-markdown-content ul > li {
  position: relative;
  padding-left: 1.75rem;
  margin-bottom: 0.6rem;
  line-height: 1.6;
}

.slide-markdown-content ul > li::before {
  content: '▸';
  position: absolute;
  left: 0.25rem;
  top: 0;
  color: #38bdf8;
  font-weight: 900;
  font-size: 1.1rem;
}

.slide-markdown-content ol {
  padding-left: 1.75rem;
  margin: 1.25rem 0;
  list-style-type: decimal;
}

.slide-markdown-content ol[type="a"] {
  list-style-type: lower-alpha;
}

.slide-markdown-content ol[type="A"] {
  list-style-type: upper-alpha;
}

.slide-markdown-content ol[type="i"] {
  list-style-type: lower-roman;
}

.slide-markdown-content ol > li {
  margin-bottom: 0.6rem;
  line-height: 1.6;
}

/* Text Formatting & Alignment */
.slide-markdown-content u {
  text-decoration: underline;
  text-underline-offset: 3px;
}

.slide-markdown-content s,
.slide-markdown-content del {
  text-decoration: line-through;
  opacity: 0.75;
}

.slide-markdown-content pre {
  max-width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  border-radius: 0.75rem;
  margin: 1rem 0;
}

.slide-markdown-content th,
.slide-markdown-content td {
  border: 1px solid rgba(255, 255, 255, 0.15);
  padding: 0.6rem 0.85rem;
  text-align: left;
}

.slide-markdown-content th {
  background: rgba(255, 255, 255, 0.08);
  font-weight: 800;
  color: #38bdf8;
}

.slide-markdown-content input[type="checkbox"] {
  margin-right: 0.5rem;
  border-radius: 0.25rem;
  accent-color: #06b6d4;
  vertical-align: middle;
}

/* Blockquotes */
.slide-markdown-content blockquote {
  border-left: 4px solid #38bdf8;
  padding: 0.75rem 1.25rem;
  margin: 1.25rem 0;
  background: rgba(56, 189, 248, 0.08);
  border-radius: 0 1rem 1rem 0;
  font-style: italic;
}

/* Canva-style Directional Slide Transitions */
.slide-left-enter-active,
.slide-left-leave-active,
.slide-right-enter-active,
.slide-right-leave-active {
  transition: all 0.32s cubic-bezier(0.25, 1, 0.5, 1);
}

.slide-left-enter-from {
  opacity: 0;
  transform: translateX(40px) scale(0.98);
}
.slide-left-leave-to {
  opacity: 0;
  transform: translateX(-40px) scale(0.98);
}

.slide-right-enter-from {
  opacity: 0;
  transform: translateX(-40px) scale(0.98);
}
.slide-right-leave-to {
  opacity: 0;
  transform: translateX(40px) scale(0.98);
}
</style>
