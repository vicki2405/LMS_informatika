<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('nilai_tps', function (Blueprint $table) {
            $table->foreignId('guru_id')->nullable()->after('catatan');
        });
    }

    public function down(): void
    {
        Schema::table('nilai_tps', function (Blueprint $table) {
            $table->dropColumn('guru_id');
        });
    }
};
