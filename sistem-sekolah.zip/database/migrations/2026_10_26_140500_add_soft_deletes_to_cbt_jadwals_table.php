<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (Schema::hasTable('cbt_jadwals') && ! Schema::hasColumn('cbt_jadwals', 'deleted_at')) {
            Schema::table('cbt_jadwals', function (Blueprint $table) {
                $table->softDeletes()->after('updated_at');
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('cbt_jadwals') && Schema::hasColumn('cbt_jadwals', 'deleted_at')) {
            Schema::table('cbt_jadwals', function (Blueprint $table) {
                $table->dropSoftDeletes();
            });
        }
    }
};
